# Email-Inbox-IMAP
A simple application example to show email inbox along with file attachments.

# Credit
This app was created using the IMAP library created by <a href="https://github.com/kirilkirkov">Kiril Kirkov</a>

<a href="http://cet.epizy.com/email/"><h2>DEMO</h2></a>
